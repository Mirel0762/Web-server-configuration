<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $filename = $_FILES['file']['name'];
    $temp_file = $_FILES['file']['tmp_name'];

    // Salvare fișier în directorul "files"
    move_uploaded_file($temp_file, "files/" . $filename);

    // Afisare link catre fișierul încărcat
    echo "Fișierul încărcat: <a href='http://www.website2.ro/files/$filename'>$filename</a>";
}
?>
