<html>
<head>
    <title>Formular</title>
</head>
<body>
    <h1>Formular GET</h1>
    <form action="action_get.php" method="GET">
        Nume: <input type="text" name="nume_get"><br>
        Email: <input type="text" name="email_get"><br>
        <input type="submit" value="Trimite">
    </form>

    <h1>Formular POST</h1>
    <form action="action_post.php" method="POST">
        Nume: <input type="text" name="nume_post"><br>
        Email: <input type="text" name="email_post"><br>
        <input type="submit" value="Trimite">
    </form>

    <h1>Formular Upload fișier</h1>
    <form action="action_upload.php" method="POST" enctype="multipart/form-data">
        Selectează un fișier: <input type="file" name="file"><br>
        <input type="submit" value="Încarcă">
    </form>
</body>
</html>
