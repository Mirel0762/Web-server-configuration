<?php
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $nume = $_GET['nume_get'];
    $email = $_GET['email_get'];

    // Generare nume fișier
    $filename = 'file-get-' . date('Ymd-His') . '.txt';

    // Salvare date în fișier
    $content = "Data și ora: " . date('Y-m-d H:i:s') . "\n";
    $content .= "IP site remote: " . $_SERVER['REMOTE_ADDR'] . "\n";
    $content .= "Pagina referer: " . $_SERVER['HTTP_REFERER'] . "\n";
    $content .= "User Agent: " . $_SERVER['HTTP_USER_AGENT'] . "\n";
    $content .= "Nume: " . $nume . "\n";
    $content .= "Email: " . $email . "\n";

    file_put_contents("files/" . $filename, $content);

    // Afisare cimpurile completate GET
    echo "Câmpurile completate GET:<br>";
    echo "Nume: " . $nume . "<br>";
    echo "Email: " . $email . "<br>";

    // Afisare link catre fisierul generat
    echo "Fișierul generat: <a href='http://www.website2.ro/files/$filename'>$filename</a>";
}
?>
