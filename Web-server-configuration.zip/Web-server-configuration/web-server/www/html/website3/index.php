<!DOCTYPE html>
<html>
<head>
    <title>Website3 - Pagini generate automat</title>
</head>
<body>
    <h1>Website3 - Pagini generate automat</h1>
    <ul>
        <li><a href="page1.php">Pagina 1</a></li>
        <li><a href="page2.php">Pagina 2</a></li>
        <li><a href="page3.php">Pagina 3</a></li>
    </ul>
</body>
</html>
