<!DOCTYPE html>
<html>
<head>
    <title>Pagina 1</title>
    <style>
        body {
            background-color: turquoise;
        }

        table {
            border-collapse: collapse;
        }

        td {
            border: 1px solid black;
            padding: 5px;
        }
    </style>
</head>
<body>
    <?php
    $servername = "localhost";
    $username = "mirel";
    $password = "ceamaisecretaparola";
    $dbname = "asul";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT * FROM tabel";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo "<h1>Pagina 1</h1>";
        echo "<table>";
        echo "<tr><th>prenume</th><th>nume</th><th>varsta</th></tr>"; // Adăugăm coloana pentru varsta
        // output data of each row
        while ($row = $result->fetch_assoc()) {
            echo "<tr><td>" . $row["prenume"] . "</td><td>" . $row["nume"] . "</td><td>" . $row["age"] . "</td></tr>"; 
        }
        echo "</table>";
    } else {
        echo "0 results";
    }
    $conn->close();
    ?>
    <br>
    <a href="index.php">Back</a>
</body>
</html>
